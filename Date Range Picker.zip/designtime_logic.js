/**
 * Date Range Picker — design time
 *
 * Renders a static, non-interactive preview of the closed field. It never opens a calendar and
 * never appends anything to <body> — a design-time control that portals leaks nodes into the
 * K2 Designer chrome.
 *
 * Design time uses Shadow DOM (the runtime deliberately does not): it isolates the preview from
 * Designer styles, and there is no popup here that would need portaling.
 */
(function () {
  'use strict';

  var KDRP_TAG = 'k2-date-range-picker';
  if (window.customElements && window.customElements.get(KDRP_TAG)) { return; }

  var KDRP_DT_MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                     'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  function kdrpDtEsc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function kdrpDtBool(v) { return v === true || v === 'true'; }
  function kdrpDtPad(n) { return (n < 10 ? '0' : '') + n; }

  function kdrpDtParse(s) {
    if (!s) { return null; }
    var m = /^(\d{4})-(\d{1,2})-(\d{1,2})/.exec(String(s).trim());
    if (!m) { return null; }
    var d = new Date(+m[1], +m[2] - 1, +m[3]);
    return isNaN(d.getTime()) ? null : d;
  }
  function kdrpDtFmt(d, fmt) {
    if (!d) { return ''; }
    var dd = kdrpDtPad(d.getDate());
    var MM = kdrpDtPad(d.getMonth() + 1);
    var yyyy = d.getFullYear();
    var MMM = KDRP_DT_MON[d.getMonth()];
    switch (fmt) {
      case 'MM/dd/yyyy':   return MM + '/' + dd + '/' + yyyy;
      case 'yyyy-MM-dd':   return yyyy + '-' + MM + '-' + dd;
      case 'dd MMM yyyy':  return dd + ' ' + MMM + ' ' + yyyy;
      case 'MMM dd, yyyy': return MMM + ' ' + dd + ', ' + yyyy;
      default:             return dd + '/' + MM + '/' + yyyy;
    }
  }

  var KdrpDtBase = (typeof K2BaseControl !== 'undefined') ? K2BaseControl : HTMLElement;

  class K2DateRangePickerDesign extends KdrpDtBase {

    static get observedAttributes() {
      return ['controlstyle', 'name', 'controltype',
              'value', 'startdate', 'enddate', 'dateformat', 'rangeseparator',
              'placeholder', 'showclearbutton', 'width', 'height',
              'isvisible', 'isenabled', 'isreadonly'];
    }

    constructor() {
      super();
      this._value = '';
      this._startDate = null;
      this._endDate = null;
      this._dateFormat = 'dd/MM/yyyy';
      this._rangeSeparator = ' - ';
      this._placeholder = 'Select dates';
      this._showClearButton = true;
      this._width = '';
      this._height = '34px';
      this._isVisible = true;
      this._isEnabled = true;
      this._isReadOnly = false;
      this._hasRendered = false;
    }

    connectedCallback() {
      if (typeof super.connectedCallback === 'function') {
        try { super.connectedCallback(); } catch (e) { /* base impl reaches jQuery */ }
      }
      if (!this._hasRendered) { this.render(); }
    }

    ensureShadow() {
      if (!this._shadow) {
        this._shadow = this.shadowRoot || this.attachShadow({ mode: 'open' });
      }
    }

    _label() {
      if (this._startDate) {
        var s = kdrpDtFmt(this._startDate, this._dateFormat);
        return this._endDate
          ? s + this._rangeSeparator + kdrpDtFmt(this._endDate, this._dateFormat)
          : s;
      }
      return this._value || '';
    }

    render() {
      this.ensureShadow();

      var label = this._label();
      var showClear = this._showClearButton && !!label;
      var interactive = this._isEnabled && !this._isReadOnly;

      this._shadow.innerHTML =
        '<style>' +
          ':host {' +
            'display: block; width: 100%;' +
            '--kdrp-accent: var(--icon-accent-color, #1495ff);' +
            '--kdrp-base: var(--icon-base-color, #495660);' +
            '--kdrp-secondary: var(--icon-base-secondary-color, #f0f0f1);' +
            '--kdrp-border: #d0d5dd;' +
            '--kdrp-text: #1f2937;' +
            '--kdrp-bg: #ffffff;' +
          '}' +
          ':host([hidden]) { display: none; }' +
          '.kdrp-field {' +
            'display: flex; align-items: center; gap: 8px;' +
            'box-sizing: border-box; width: 100%;' +
            'height: ' + kdrpDtEsc(this._height || '34px') + ';' +
            'padding-inline: 10px;' +
            'border: 1px solid var(--kdrp-border); border-radius: 4px;' +
            'background: ' + (interactive ? 'var(--kdrp-bg)' : 'var(--kdrp-secondary)') + ';' +
            'color: var(--kdrp-text); font: inherit;' +
            'opacity: ' + (this._isEnabled ? '1' : '0.5') + ';' +
          '}' +
          '.kdrp-cal-icon {' +
            'flex: 0 0 auto; position: relative; width: 14px; height: 14px;' +
            'border: 1.5px solid var(--kdrp-base); border-radius: 2px;' +
          '}' +
          '.kdrp-cal-icon::before {' +
            'content: ""; position: absolute; inset-inline: 1px; top: 2px;' +
            'height: 1.5px; background: var(--kdrp-base);' +
          '}' +
          '.kdrp-text {' +
            'flex: 1 1 auto; min-width: 0; text-align: start;' +
            'white-space: nowrap; overflow: hidden; text-overflow: ellipsis;' +
            'color: ' + (label ? 'var(--kdrp-text)' : '#9ca3af') + ';' +
          '}' +
          '.kdrp-clear { flex: 0 0 auto; color: var(--kdrp-base); font-size: 12px; }' +
        '</style>' +
        '<div class="kdrp-field" part="field">' +
          '<span class="kdrp-cal-icon"></span>' +
          '<span class="kdrp-text">' + kdrpDtEsc(label || this._placeholder) + '</span>' +
          (showClear ? '<span class="kdrp-clear">&#x2715;</span>' : '') +
        '</div>';

      this.style.display = this._isVisible ? '' : 'none';
      if (this._width) {
        this.style.width = isNaN(this._width) ? String(this._width) : this._width + 'px';
      }
      this._hasRendered = true;
    }

    /* ------------------------------------------------------------- properties */

    get Value() { return this._value; }
    set Value(v) {
      this._value = (v == null) ? '' : String(v);
      if (this._hasRendered) { this.render(); }
    }

    get StartDate() { return this._startDate; }
    set StartDate(v) {
      this._startDate = kdrpDtParse(v);
      if (this._hasRendered) { this.render(); }
    }

    get EndDate() { return this._endDate; }
    set EndDate(v) {
      this._endDate = kdrpDtParse(v);
      if (this._hasRendered) { this.render(); }
    }

    get DateFormat() { return this._dateFormat; }
    set DateFormat(v) {
      this._dateFormat = (v == null || v === '') ? 'dd/MM/yyyy' : String(v);
      if (this._hasRendered) { this.render(); }
    }

    get RangeSeparator() { return this._rangeSeparator; }
    set RangeSeparator(v) {
      this._rangeSeparator = (v == null) ? '' : String(v);
      if (this._hasRendered) { this.render(); }
    }

    get Placeholder() { return this._placeholder; }
    set Placeholder(v) {
      this._placeholder = (v == null) ? '' : String(v);
      if (this._hasRendered) { this.render(); }
    }

    get ShowClearButton() { return this._showClearButton; }
    set ShowClearButton(v) {
      this._showClearButton = kdrpDtBool(v);
      if (this._hasRendered) { this.render(); }
    }

    get Width() { return this._width; }
    set Width(v) { this._width = v; if (this._hasRendered) { this.render(); } }

    get Height() { return this._height; }
    set Height(v) { this._height = v; if (this._hasRendered) { this.render(); } }

    get IsVisible() { return this._isVisible; }
    set IsVisible(v) {
      this._isVisible = kdrpDtBool(v);
      this.style.display = this._isVisible ? '' : 'none';
    }

    get IsEnabled() { return this._isEnabled; }
    set IsEnabled(v) { this._isEnabled = kdrpDtBool(v); if (this._hasRendered) { this.render(); } }

    get IsReadOnly() { return this._isReadOnly; }
    set IsReadOnly(v) { this._isReadOnly = kdrpDtBool(v); if (this._hasRendered) { this.render(); } }

    // Accept-and-ignore so the designer can set anything without throwing.
    get TotalDays() { return ''; }
    set TotalDays(v) { }

    onAttributeChanged(name, oldValue, newValue) {
      switch (name) {
        case 'value':           this.Value = newValue; break;
        case 'startdate':       this.StartDate = newValue; break;
        case 'enddate':         this.EndDate = newValue; break;
        case 'dateformat':      this.DateFormat = newValue; break;
        case 'rangeseparator':  this.RangeSeparator = newValue; break;
        case 'placeholder':     this.Placeholder = newValue; break;
        case 'showclearbutton': this.ShowClearButton = newValue; break;
        case 'width':           this.Width = newValue; break;
        case 'height':          this.Height = newValue; break;
        case 'isvisible':       this.IsVisible = newValue; break;
        case 'isenabled':       this.IsEnabled = newValue; break;
        case 'isreadonly':      this.IsReadOnly = newValue; break;
        default:
          if (typeof super.onAttributeChanged === 'function') {
            super.onAttributeChanged(name, oldValue, newValue);
          }
      }
    }

    attributeChangedCallback(name, oldValue, newValue) {
      if (oldValue === newValue) { return; }
      if (KdrpDtBase !== HTMLElement && typeof super.attributeChangedCallback === 'function') {
        super.attributeChangedCallback(name, oldValue, newValue);
      } else {
        this.onAttributeChanged(name, oldValue, newValue);
      }
    }

    execute(objInfo) { return ''; }
  }

  window.customElements.define(KDRP_TAG, K2DateRangePickerDesign);
})();
