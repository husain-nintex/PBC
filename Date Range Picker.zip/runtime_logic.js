/**
 * Date Range Picker — runtime
 *
 * Booking-style range picker: click a start date, click an end date, done. The calendar is
 * portaled to <body> so a K2 form panel cannot clip it, and carries no z-index (K2 Designer
 * overlays do not use one, so a positive value would sit on top of the rule designer).
 *
 * Outputs three properties:
 *   StartDate  — ISO yyyy-MM-dd
 *   EndDate    — ISO yyyy-MM-dd
 *   Value      — the whole range as one formatted string (the control's primary value)
 * plus TotalDays as a read-back convenience.
 *
 * All date maths is local-midnight based. Dates are never round-tripped through Date.parse on
 * a bare 'yyyy-MM-dd' string, because that parses as UTC and shifts a day in negative offsets.
 */
(function () {
  'use strict';

  var KDRP_TAG = 'k2-date-range-picker';
  if (window.customElements && window.customElements.get(KDRP_TAG)) { return; }

  var KDRP_MONTHS = ['January', 'February', 'March', 'April', 'May', 'June',
                     'July', 'August', 'September', 'October', 'November', 'December'];
  var KDRP_MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  var KDRP_DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  /* ---------------------------------------------------------------- helpers
     Prefixed: all control scripts share one global scope. */

  function kdrpRaise(ctrl, prop, value) {
    try {
      if (window.K2 && typeof window.K2.RaisePropertyChanged === 'function') {
        window.K2.RaisePropertyChanged(ctrl, prop, value);
      }
    } catch (e) {
      console.warn('[' + KDRP_TAG + '] RaisePropertyChanged failed:', e);
    }
  }

  function kdrpEsc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function kdrpBool(v) { return v === true || v === 'true'; }
  function kdrpInt(v, dflt) { var n = parseInt(v, 10); return (isNaN(n) || n <= 0) ? dflt : n; }
  function kdrpPad(n) { return (n < 10 ? '0' : '') + n; }

  /** Local-midnight Date from yyyy-MM-dd (or anything Date can parse). null when empty/invalid. */
  function kdrpParse(s) {
    if (s == null || s === '') { return null; }
    if (s instanceof Date) { return isNaN(s.getTime()) ? null : kdrpMidnight(s); }
    var str = String(s).trim();
    var m = /^(\d{4})-(\d{1,2})-(\d{1,2})/.exec(str);
    if (m) {
      var d = new Date(+m[1], +m[2] - 1, +m[3]);
      return isNaN(d.getTime()) ? null : d;
    }
    var parsed = new Date(str);          // last resort: locale/ISO-with-time strings
    return isNaN(parsed.getTime()) ? null : kdrpMidnight(parsed);
  }
  function kdrpMidnight(d) { return new Date(d.getFullYear(), d.getMonth(), d.getDate()); }
  function kdrpToday() { return kdrpMidnight(new Date()); }
  function kdrpISO(d) {
    return d ? d.getFullYear() + '-' + kdrpPad(d.getMonth() + 1) + '-' + kdrpPad(d.getDate()) : '';
  }
  function kdrpAddDays(d, n) { return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n); }
  function kdrpAddMonths(d, n) { return new Date(d.getFullYear(), d.getMonth() + n, 1); }
  function kdrpSame(a, b) { return !!a && !!b && a.getTime() === b.getTime(); }
  /** Inclusive day span: same day => 1. */
  function kdrpSpan(a, b) {
    return Math.round((b.getTime() - a.getTime()) / 86400000) + 1;
  }

  function kdrpFmt(d, fmt) {
    if (!d) { return ''; }
    var dd = kdrpPad(d.getDate());
    var MM = kdrpPad(d.getMonth() + 1);
    var yyyy = d.getFullYear();
    var MMM = KDRP_MON[d.getMonth()];
    switch (fmt) {
      case 'MM/dd/yyyy':  return MM + '/' + dd + '/' + yyyy;
      case 'yyyy-MM-dd':  return yyyy + '-' + MM + '-' + dd;
      case 'dd MMM yyyy': return dd + ' ' + MMM + ' ' + yyyy;
      case 'MMM dd, yyyy':return MMM + ' ' + dd + ', ' + yyyy;
      default:            return dd + '/' + MM + '/' + yyyy;
    }
  }

  /** Parse a formatted date back to a Date, tolerating the five supported formats. */
  function kdrpParseFormatted(str, fmt) {
    if (!str) { return null; }
    var s = String(str).trim();
    var iso = kdrpParse(s);
    if (iso && /^\d{4}-/.test(s)) { return iso; }

    var mon = /^(\d{1,2})\s+([A-Za-z]{3})[a-z]*\s+(\d{4})$/.exec(s);          // 31 Dec 2026
    if (mon) {
      var mi = KDRP_MON.indexOf(mon[2].slice(0, 3));
      if (mi >= 0) { return new Date(+mon[3], mi, +mon[1]); }
    }
    var mon2 = /^([A-Za-z]{3})[a-z]*\s+(\d{1,2}),?\s+(\d{4})$/.exec(s);        // Dec 31, 2026
    if (mon2) {
      var mi2 = KDRP_MON.indexOf(mon2[1].slice(0, 3));
      if (mi2 >= 0) { return new Date(+mon2[3], mi2, +mon2[2]); }
    }
    var num = /^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/.exec(s);
    if (num) {
      var a = +num[1], b = +num[2], y = +num[3];
      // Where one value cannot be a month the order is unambiguous; otherwise trust the format.
      if (a > 12) { return new Date(y, b - 1, a); }   // must be dd/MM
      if (b > 12) { return new Date(y, a - 1, b); }   // must be MM/dd
      return fmt === 'MM/dd/yyyy' ? new Date(y, a - 1, b) : new Date(y, b - 1, a);
    }
    return iso;
  }

  var KdrpBase = (typeof K2BaseControl !== 'undefined') ? K2BaseControl : HTMLElement;

  class K2DateRangePicker extends KdrpBase {

    static get observedAttributes() {
      return ['controlstyle', 'name', 'controltype',
              'value', 'startdate', 'enddate',
              'allowpastdates', 'allowfuturedates', 'mindate', 'maxdate', 'disableweekends',
              'minrangedays', 'maxrangedays',
              'dateformat', 'rangeseparator', 'monthstoshow', 'firstdayofweek',
              'placeholder', 'showdaycount', 'showclearbutton',
              'width', 'height', 'isvisible', 'isenabled', 'isreadonly', 'tabindex'];
    }

    constructor() {
      super();

      // selection
      this._startDate = null;
      this._endDate = null;
      this._value = '';
      this._totalDays = '';
      this._pickPhase = 'start';       // 'start' | 'end'
      this._hoverDate = null;

      // calendar view
      this._viewMonth = null;          // Date pinned to the 1st of the leftmost visible month
      this._focusDate = null;          // virtually-focused day (aria-activedescendant)
      this._isOpen = false;

      // restrictions
      this._allowPastDates = true;
      this._allowFutureDates = true;
      this._minDate = null;
      this._maxDate = null;
      this._disableWeekends = false;
      this._minRangeDays = 1;
      this._maxRangeDays = 365;

      // appearance — defaults MUST match the manifest initialvalue entries
      this._dateFormat = 'dd/MM/yyyy';
      this._rangeSeparator = ' - ';
      this._monthsToShow = 2;
      this._firstDayOfWeek = 1;
      this._placeholder = 'Select dates';
      this._showDayCount = true;
      this._showClearButton = true;

      // standard properties
      this._width = '';
      this._height = '34px';
      this._isVisible = true;
      this._isEnabled = true;
      this._isReadOnly = false;
      this._tabIndex = '0';

      // internals
      this._hasRendered = false;
      this._isRendering = false;
      this._reflowRaf = null;
      this._uid = 'kdrp-' + Math.random().toString(36).slice(2, 10);
      this._onDocPointerDown = this._handleDocPointerDown.bind(this);
      this._onReflow = this._handleReflow.bind(this);
    }

    /* ------------------------------------------------------------- lifecycle */

    connectedCallback() {
      if (typeof super.connectedCallback === 'function') {
        try { super.connectedCallback(); } catch (e) { /* base impl reaches jQuery */ }
      }
      if (!this._hasRendered) { this.render(); }
    }

    disconnectedCallback() {
      try {
        if (typeof super.disconnectedCallback === 'function') { super.disconnectedCallback(); }
      } catch (e) { /* base impl calls $(this._shadow).off() */ }
      this._closeCalendar(true);
      if (this._popup && this._popup.parentNode) {
        this._popup.parentNode.removeChild(this._popup);
      }
      document.removeEventListener('pointerdown', this._onDocPointerDown, true);
      window.removeEventListener('scroll', this._onReflow, true);
      window.removeEventListener('resize', this._onReflow, true);
      this._hasRendered = false;
    }

    // Light DOM at runtime so runtime_style.css (a document-level <link>) applies and the
    // popup can be portaled. _shadow must still be set before attachEventListeners().
    ensureShadow() { this._shadow = this; }

    render() {
      if (this._hasRendered || this._isRendering) { return; }
      this._isRendering = true;
      try {
        this.ensureShadow();
        var u = this._uid;

        this.innerHTML =
          '<div class="kdrp-root">' +
            '<div class="kdrp-field" role="group">' +
              '<span class="kdrp-cal-icon" aria-hidden="true"></span>' +
              '<input class="kdrp-input" id="' + u + '-input" type="text" readonly' +
                    ' role="combobox" aria-haspopup="dialog" aria-expanded="false"' +
                    ' aria-controls="' + u + '-popup"' +
                    ' autocomplete="off" spellcheck="false"' +
                    ' tabindex="' + kdrpEsc(this._tabIndex) + '"' +
                    ' placeholder="' + kdrpEsc(this._placeholder) + '" />' +
              '<button class="kdrp-clear" type="button" tabindex="-1" hidden' +
                     ' aria-label="Clear date range">&#x2715;</button>' +
            '</div>' +
            '<span class="kdrp-live" id="' + u + '-live" role="status"' +
                 ' aria-live="polite" aria-atomic="true"></span>' +
          '</div>';

        this._root = this.querySelector('.kdrp-root');
        this._field = this.querySelector('.kdrp-field');
        this._input = this.querySelector('.kdrp-input');
        this._clear = this.querySelector('.kdrp-clear');
        this._live = this.querySelector('.kdrp-live');

        // Popup is created detached and only ever appended to <body>.
        this._popup = document.createElement('div');
        this._popup.className = 'kdrp-popup';
        this._popup.id = u + '-popup';
        this._popup.setAttribute('data-portal', 'true');
        this._popup.setAttribute('role', 'dialog');
        this._popup.setAttribute('aria-label', 'Choose a date range');
        this._popup.innerHTML =
          '<div class="kdrp-head">' +
            '<button class="kdrp-nav kdrp-prev" type="button" tabindex="-1"' +
                   ' aria-label="Previous month">&#x2039;</button>' +
            '<button class="kdrp-nav kdrp-next" type="button" tabindex="-1"' +
                   ' aria-label="Next month">&#x203A;</button>' +
          '</div>' +
          '<div class="kdrp-panels"></div>' +
          '<div class="kdrp-foot">' +
            '<span class="kdrp-summary"></span>' +
            '<button class="kdrp-reset" type="button" tabindex="-1">Clear</button>' +
          '</div>';
        this._panels = this._popup.querySelector('.kdrp-panels');
        this._summary = this._popup.querySelector('.kdrp-summary');

        this._attachEvents();
        this._hasRendered = true;

        this._applyStandardProperties();
        this._syncFieldText();
        this._updateClearButton();

        if (typeof this.attachEventListeners === 'function') {
          try { this.attachEventListeners(); } catch (e) { /* base impl reaches jQuery */ }
        }
        this.dispatchEvent(new Event('Rendered'));
      } finally {
        this._isRendering = false;
      }
    }

    /* ------------------------------------------------------ date restrictions */

    /** Floor implied by AllowPastDates plus the explicit MinDate. */
    _effectiveMin() {
      var floors = [];
      if (!this._allowPastDates) { floors.push(kdrpToday()); }
      if (this._minDate) { floors.push(this._minDate); }
      if (!floors.length) { return null; }
      return floors.reduce(function (a, b) { return a.getTime() > b.getTime() ? a : b; });
    }
    _effectiveMax() {
      var ceils = [];
      if (!this._allowFutureDates) { ceils.push(kdrpToday()); }
      if (this._maxDate) { ceils.push(this._maxDate); }
      if (!ceils.length) { return null; }
      return ceils.reduce(function (a, b) { return a.getTime() < b.getTime() ? a : b; });
    }

    /** Base selectability, ignoring which end of the range is being picked. */
    _isBlocked(d) {
      var lo = this._effectiveMin();
      var hi = this._effectiveMax();
      if (lo && d.getTime() < lo.getTime()) { return true; }
      if (hi && d.getTime() > hi.getTime()) { return true; }
      if (this._disableWeekends) {
        var dow = d.getDay();
        if (dow === 0 || dow === 6) { return true; }
      }
      return false;
    }

    /**
     * Selectability for the current pick phase. While choosing the end date, dates that would
     * breach MinRangeDays/MaxRangeDays are blocked — but dates BEFORE the start stay open,
     * because clicking one restarts the range (standard booking-site behaviour).
     */
    _isBlockedNow(d) {
      if (this._isBlocked(d)) { return true; }
      if (this._pickPhase === 'end' && this._startDate) {
        if (d.getTime() < this._startDate.getTime()) { return false; }   // restart
        var span = kdrpSpan(this._startDate, d);
        if (span < this._minRangeDays) { return true; }
        if (this._maxRangeDays > 0 && span > this._maxRangeDays) { return true; }
      }
      return false;
    }

    /* ------------------------------------------------------------- rendering */

    _dowLabels() {
      var out = [];
      for (var i = 0; i < 7; i++) { out.push(KDRP_DOW[(this._firstDayOfWeek + i) % 7]); }
      return out;
    }

    _renderCalendar() {
      if (!this._viewMonth) { this._viewMonth = this._defaultViewMonth(); }
      var html = '';
      for (var p = 0; p < this._monthsToShow; p++) {
        html += this._renderMonth(kdrpAddMonths(this._viewMonth, p));
      }
      this._panels.innerHTML = html;
      this._renderSummary();
      this._syncNavState();
    }

    _renderMonth(monthDate) {
      var u = this._uid;
      var year = monthDate.getFullYear();
      var month = monthDate.getMonth();
      var first = new Date(year, month, 1);
      var daysInMonth = new Date(year, month + 1, 0).getDate();

      // leading blanks so the 1st lands under the right weekday
      var lead = (first.getDay() - this._firstDayOfWeek + 7) % 7;

      var head = '<div class="kdrp-panel">' +
        '<div class="kdrp-title">' + KDRP_MONTHS[month] + ' ' + year + '</div>' +
        '<div class="kdrp-dow">' +
          this._dowLabels().map(function (d) {
            return '<span class="kdrp-dow-cell" aria-hidden="true">' + d + '</span>';
          }).join('') +
        '</div>' +
        '<div class="kdrp-grid" role="grid" aria-label="' +
          kdrpEsc(KDRP_MONTHS[month] + ' ' + year) + '">';

      var cells = '';
      for (var i = 0; i < lead; i++) {
        cells += '<span class="kdrp-cell kdrp-cell--blank" role="presentation"></span>';
      }

      var today = kdrpToday();
      // While picking the end date, preview the range under the pointer / virtual focus.
      var previewEnd = (this._pickPhase === 'end' && this._startDate)
        ? (this._hoverDate || this._focusDate) : null;

      for (var day = 1; day <= daysInMonth; day++) {
        var d = new Date(year, month, day);
        var t = d.getTime();
        var blocked = this._isBlockedNow(d);

        var isStart = kdrpSame(d, this._startDate);
        var isEnd = kdrpSame(d, this._endDate);
        var inRange = false, isPreviewEnd = false;

        if (this._startDate && this._endDate) {
          inRange = t > this._startDate.getTime() && t < this._endDate.getTime();
        } else if (previewEnd && previewEnd.getTime() >= this._startDate.getTime()) {
          inRange = t > this._startDate.getTime() && t < previewEnd.getTime();
          isPreviewEnd = kdrpSame(d, previewEnd);
        }

        var cls = 'kdrp-cell';
        if (blocked) { cls += ' kdrp-cell--blocked'; }
        if (isStart) { cls += ' kdrp-cell--start'; }
        if (isEnd || isPreviewEnd) { cls += ' kdrp-cell--end'; }
        if (inRange) { cls += ' kdrp-cell--in'; }
        if (kdrpSame(d, today)) { cls += ' kdrp-cell--today'; }
        if (kdrpSame(d, this._focusDate)) { cls += ' kdrp-cell--focus'; }

        var selected = (isStart || isEnd) ? 'true' : 'false';
        cells += '<span class="' + cls + '" role="gridcell"' +
                 ' id="' + u + '-d-' + kdrpISO(d) + '"' +
                 ' data-date="' + kdrpISO(d) + '"' +
                 ' aria-selected="' + selected + '"' +
                 (blocked ? ' aria-disabled="true"' : '') +
                 ' aria-label="' + kdrpEsc(kdrpFmt(d, 'dd MMM yyyy')) + '">' +
                 '<span class="kdrp-day">' + day + '</span></span>';
      }

      return head + cells + '</div></div>';
    }

    /**
     * Repaint only the range-dependent classes on the existing cells.
     * Hover fires constantly, and rebuilding the whole grid each time flickers — only the
     * in-range band and the preview end cap actually change while the pointer moves.
     */
    _paintRange() {
      if (!this._isOpen || !this._panels) { return; }
      var start = this._startDate;
      var previewEnd = (this._pickPhase === 'end' && start)
        ? (this._hoverDate || this._focusDate) : null;
      var hasPreview = !!(previewEnd && previewEnd.getTime() >= start.getTime());

      var cells = this._panels.querySelectorAll('.kdrp-cell[data-date]');
      for (var i = 0; i < cells.length; i++) {
        var cell = cells[i];
        var t = kdrpParse(cell.getAttribute('data-date')).getTime();
        var inRange = false, isPreviewEnd = false;

        if (start && this._endDate) {
          inRange = t > start.getTime() && t < this._endDate.getTime();
        } else if (hasPreview) {
          inRange = t > start.getTime() && t < previewEnd.getTime();
          isPreviewEnd = t === previewEnd.getTime();
        }
        cell.classList.toggle('kdrp-cell--in', inRange);
        // Never strip the committed end cap while repainting a preview.
        if (!kdrpSame(kdrpParse(cell.getAttribute('data-date')), this._endDate)) {
          cell.classList.toggle('kdrp-cell--end', isPreviewEnd);
        }
      }
      this._renderSummary();
    }

    _renderSummary() {
      if (!this._summary) { return; }
      if (!this._showDayCount) { this._summary.textContent = ''; return; }
      if (this._startDate && this._endDate) {
        var n = kdrpSpan(this._startDate, this._endDate);
        this._summary.textContent = n + (n === 1 ? ' day selected' : ' days selected');
      } else if (this._startDate) {
        this._summary.textContent = 'Select the end date';
      } else {
        this._summary.textContent = 'Select the start date';
      }
    }

    _syncNavState() {
      var prev = this._popup.querySelector('.kdrp-prev');
      var next = this._popup.querySelector('.kdrp-next');
      var lo = this._effectiveMin();
      var hi = this._effectiveMax();
      // Disable navigation once the whole visible span is outside the allowed window.
      var prevMonthEnd = new Date(this._viewMonth.getFullYear(), this._viewMonth.getMonth(), 0);
      var nextMonthStart = kdrpAddMonths(this._viewMonth, this._monthsToShow);
      if (prev) { prev.disabled = !!(lo && prevMonthEnd.getTime() < lo.getTime()); }
      if (next) { next.disabled = !!(hi && nextMonthStart.getTime() > hi.getTime()); }
    }

    _defaultViewMonth() {
      var anchor = this._startDate || this._clampToWindow(kdrpToday());
      return new Date(anchor.getFullYear(), anchor.getMonth(), 1);
    }
    _clampToWindow(d) {
      var lo = this._effectiveMin();
      var hi = this._effectiveMax();
      if (lo && d.getTime() < lo.getTime()) { return lo; }
      if (hi && d.getTime() > hi.getTime()) { return hi; }
      return d;
    }

    /* --------------------------------------------------- open / close / place */

    _openCalendar() {
      if (!this._hasRendered) { return; }
      if (this._isOpen) { this._positionPopup(); return; }
      if (!this._isEnabled || this._isReadOnly) { return; }

      if (!this._popup.parentNode) { document.body.appendChild(this._popup); }
      this._syncPortalContext();

      this._pickPhase = 'start';
      this._hoverDate = null;
      this._viewMonth = this._defaultViewMonth();
      this._focusDate = this._clampToWindow(this._startDate || kdrpToday());
      this._renderCalendar();

      this._popup.style.position = 'fixed';    // no z-index — DOM order handles stacking
      this._popup.style.display = 'block';
      this._positionPopup();

      this._isOpen = true;
      this._input.setAttribute('aria-expanded', 'true');
      this._root.classList.add('kdrp-root--open');

      document.addEventListener('pointerdown', this._onDocPointerDown, true);
      window.addEventListener('scroll', this._onReflow, true);
      window.addEventListener('resize', this._onReflow, true);

      this._announce();
      this.dispatchEvent(new CustomEvent('OnOpened', { bubbles: true, detail: {} }));
    }

    _closeCalendar(silent) {
      if (!this._isOpen) { return; }
      this._isOpen = false;
      this._hoverDate = null;
      if (this._popup) { this._popup.style.display = 'none'; }
      if (this._input) {
        this._input.setAttribute('aria-expanded', 'false');
        this._input.removeAttribute('aria-activedescendant');
      }
      if (this._root) { this._root.classList.remove('kdrp-root--open'); }

      document.removeEventListener('pointerdown', this._onDocPointerDown, true);
      window.removeEventListener('scroll', this._onReflow, true);
      window.removeEventListener('resize', this._onReflow, true);

      if (!silent) {
        this.dispatchEvent(new CustomEvent('OnClosed', { bubbles: true, detail: {} }));
      }
    }

    // Portaled nodes inherit from <body>, not from the host — re-stamp what matters.
    _syncPortalContext() {
      var cs = window.getComputedStyle(this);
      var popup = this._popup;
      ['--icon-accent-color', '--icon-base-color',
       '--icon-base-secondary-color', '--icon-attention-color'].forEach(function (v) {
        var val = cs.getPropertyValue(v);
        if (val && val.trim()) { popup.style.setProperty(v, val.trim()); }
      });
      popup.style.fontFamily = cs.fontFamily;
      popup.style.fontSize = cs.fontSize;
      var dir = (cs.direction || 'ltr').toLowerCase();
      popup.dir = dir;
      popup.classList.toggle('kdrp-popup--rtl', dir === 'rtl');
      popup.classList.toggle('kdrp-popup--single', this._monthsToShow === 1);
    }

    _positionPopup() {
      var rect = this._field.getBoundingClientRect();
      var dir = (this._popup.dir || 'ltr').toLowerCase();

      this._popup.style.visibility = 'hidden';
      this._popup.style.display = 'block';

      var ph = this._popup.offsetHeight;
      var pw = this._popup.offsetWidth;
      var vw = window.innerWidth;
      var vh = window.innerHeight;

      var top = rect.bottom + 4;
      if (top + ph > vh - 8 && rect.top - ph - 4 > 8) { top = rect.top - ph - 4; }
      var left = (dir === 'rtl') ? (rect.right - pw) : rect.left;
      if (left + pw > vw - 8) { left = vw - pw - 8; }
      if (left < 8) { left = 8; }
      if (top < 8) { top = 8; }

      this._popup.style.top = top + 'px';
      this._popup.style.left = left + 'px';
      this._popup.style.visibility = '';
    }

    _handleReflow() {
      if (!this._isOpen || this._reflowRaf) { return; }
      var self = this;
      this._reflowRaf = requestAnimationFrame(function () {
        self._reflowRaf = null;
        if (!self._isOpen) { return; }
        var r = self._field.getBoundingClientRect();
        if (r.bottom < 0 || r.top > window.innerHeight) { self._closeCalendar(); return; }
        self._positionPopup();
      });
    }

    _handleDocPointerDown(e) {
      if (this.contains(e.target)) { return; }
      if (this._popup && this._popup.contains(e.target)) { return; }
      this._closeCalendar();
    }

    /* ------------------------------------------------------------- selection */

    _pickDate(d) {
      if (!d || this._isBlockedNow(d)) {
        if (d && this._pickPhase === 'end' && this._startDate &&
            d.getTime() >= this._startDate.getTime() && !this._isBlocked(d)) {
          // Blocked purely by the range rules — tell the form why.
          var span = kdrpSpan(this._startDate, d);
          this.dispatchEvent(new CustomEvent('OnInvalidRange', {
            bubbles: true,
            detail: {
              attemptedDays: span,
              minRangeDays: this._minRangeDays,
              maxRangeDays: this._maxRangeDays,
              reason: span < this._minRangeDays ? 'below-minimum' : 'above-maximum'
            }
          }));
          this._announce(span < this._minRangeDays
            ? 'Minimum range is ' + this._minRangeDays + ' days'
            : 'Maximum range is ' + this._maxRangeDays + ' days');
        }
        return;
      }

      if (this._pickPhase === 'start' || !this._startDate ||
          (this._startDate && this._endDate)) {
        // begin a new range
        this._startDate = d;
        this._endDate = null;
        this._pickPhase = 'end';
        this._focusDate = d;
        this._commit(false);
        this._renderCalendar();
        this._announce('Start date ' + kdrpFmt(d, 'dd MMM yyyy') + '. Now select the end date.');
        this.dispatchEvent(new CustomEvent('OnStartDateSelected', {
          bubbles: true, detail: { startDate: kdrpISO(d) }
        }));
        return;
      }

      if (d.getTime() < this._startDate.getTime()) {
        // clicking before the start restarts the range
        this._startDate = d;
        this._endDate = null;
        this._focusDate = d;
        this._commit(false);
        this._renderCalendar();
        this._announce('Start date ' + kdrpFmt(d, 'dd MMM yyyy') + '. Now select the end date.');
        this.dispatchEvent(new CustomEvent('OnStartDateSelected', {
          bubbles: true, detail: { startDate: kdrpISO(d) }
        }));
        return;
      }

      this._endDate = d;
      this._pickPhase = 'start';
      this._focusDate = d;
      // Commit without firing, so the specific event lands before the aggregate one.
      var prevValue = this._commit(false);
      this._renderCalendar();
      this.dispatchEvent(new CustomEvent('OnEndDateSelected', {
        bubbles: true, detail: { endDate: kdrpISO(d) }
      }));
      if (prevValue !== null) { this._dispatchChanged(prevValue); }
      this._closeCalendar();
      this._input.focus();
    }

    /**
     * Push state into the properties. Returns the previous value when it changed, else null,
     * so callers can order OnChanged after their own more specific event.
     */
    _commit(fireChanged) {
      var oldValue = this._value;
      var sIso = kdrpISO(this._startDate);
      var eIso = kdrpISO(this._endDate);

      this._value = this._composeValue();
      this._totalDays = (this._startDate && this._endDate)
        ? String(kdrpSpan(this._startDate, this._endDate)) : '';

      // backing fields first, then attributes, then notify
      this.setAttribute('value', this._value);
      this.setAttribute('startdate', sIso);
      this.setAttribute('enddate', eIso);

      this._syncFieldText();
      this._updateClearButton();

      if (this._hasRendered) {
        kdrpRaise(this, 'Value', this._value);
        kdrpRaise(this, 'StartDate', sIso);
        kdrpRaise(this, 'EndDate', eIso);
        kdrpRaise(this, 'TotalDays', this._totalDays);
      }

      if (this._value === oldValue) { return null; }
      if (fireChanged) { this._dispatchChanged(oldValue); }
      return oldValue;
    }

    _dispatchChanged(oldValue) {
      this.dispatchEvent(new CustomEvent('OnChanged', {
        bubbles: true,
        detail: {
          value: this._value,
          startDate: kdrpISO(this._startDate),
          endDate: kdrpISO(this._endDate),
          totalDays: this._totalDays,
          oldValue: oldValue
        }
      }));
    }

    _composeValue() {
      if (!this._startDate) { return ''; }
      var s = kdrpFmt(this._startDate, this._dateFormat);
      if (!this._endDate) { return s; }
      return s + this._rangeSeparator + kdrpFmt(this._endDate, this._dateFormat);
    }

    _syncFieldText() {
      if (this._input) { this._input.value = this._composeValue(); }
    }
    _updateClearButton() {
      if (!this._clear) { return; }
      this._clear.hidden = !(this._showClearButton && !!this._startDate &&
                             this._isEnabled && !this._isReadOnly);
    }
    _announce(msg) {
      if (!this._live) { return; }
      if (msg) { this._live.textContent = msg; return; }
      if (this._startDate && this._endDate) {
        this._live.textContent = kdrpSpan(this._startDate, this._endDate) + ' days selected';
      } else if (this._startDate) {
        this._live.textContent = 'Start date chosen. Select the end date.';
      } else {
        this._live.textContent = 'Select the start date.';
      }
    }

    _clearSelection(fireEvents) {
      var had = !!this._startDate;
      this._startDate = null;
      this._endDate = null;
      this._pickPhase = 'start';
      this._hoverDate = null;
      var prevValue = this._commit(false);
      if (this._isOpen) { this._renderCalendar(); }
      if (fireEvents && had) {
        this.dispatchEvent(new CustomEvent('OnCleared', { bubbles: true, detail: {} }));
        if (prevValue !== null) { this._dispatchChanged(prevValue); }
      }
    }

    /* ---------------------------------------------------------------- events */

    _attachEvents() {
      var self = this;

      this._field.addEventListener('mousedown', function (e) {
        if (e.target === self._clear) { return; }
        e.preventDefault();
        if (!self._isEnabled || self._isReadOnly) { return; }
        if (self._isOpen) { self._closeCalendar(); } else { self._openCalendar(); }
        self._input.focus();
      });

      this._input.addEventListener('focus', function () {
        self.dispatchEvent(new CustomEvent('OnFocus', { bubbles: true, detail: {} }));
      });
      this._input.addEventListener('blur', function () {
        self.dispatchEvent(new CustomEvent('OnBlur', { bubbles: true, detail: {} }));
      });
      this._input.addEventListener('keydown', function (e) { self._onKeyDown(e); });

      this._clear.addEventListener('mousedown', function (e) { e.preventDefault(); });
      this._clear.addEventListener('click', function (e) {
        e.stopPropagation();
        if (!self._isEnabled || self._isReadOnly) { return; }
        self._clearSelection(true);
        self._input.focus();
      });

      // Popup interactions. Keep focus on the input throughout.
      this._popup.addEventListener('mousedown', function (e) { e.preventDefault(); });

      this._popup.addEventListener('click', function (e) {
        var nav = e.target.closest ? e.target.closest('.kdrp-nav') : null;
        if (nav) {
          if (nav.disabled) { return; }
          self._shiftMonths(nav.classList.contains('kdrp-prev') ? -1 : 1);
          return;
        }
        if (e.target.closest && e.target.closest('.kdrp-reset')) {
          self._clearSelection(true);
          return;
        }
        var cell = e.target.closest ? e.target.closest('.kdrp-cell[data-date]') : null;
        if (cell) { self._pickDate(kdrpParse(cell.getAttribute('data-date'))); }
      });

      // Hover preview of the pending range.
      this._popup.addEventListener('mouseover', function (e) {
        if (self._pickPhase !== 'end' || !self._startDate) { return; }
        var cell = e.target.closest ? e.target.closest('.kdrp-cell[data-date]') : null;
        if (!cell) { return; }
        var d = kdrpParse(cell.getAttribute('data-date'));
        if (kdrpSame(d, self._hoverDate)) { return; }
        self._hoverDate = d;
        self._paintRange();
      });
      this._popup.addEventListener('mouseleave', function () {
        if (self._hoverDate) { self._hoverDate = null; self._paintRange(); }
      });
    }

    _shiftMonths(delta) {
      this._viewMonth = kdrpAddMonths(this._viewMonth, delta);
      this._renderCalendar();
    }

    /** Move virtual focus, scrolling the visible months to follow. */
    _moveFocus(days) {
      if (!this._focusDate) { this._focusDate = this._clampToWindow(kdrpToday()); }
      var next = kdrpAddDays(this._focusDate, days);
      var lo = this._effectiveMin();
      var hi = this._effectiveMax();
      if (lo && next.getTime() < lo.getTime()) { return; }
      if (hi && next.getTime() > hi.getTime()) { return; }
      this._focusDate = next;

      var firstVisible = this._viewMonth;
      var lastVisible = new Date(this._viewMonth.getFullYear(),
                                 this._viewMonth.getMonth() + this._monthsToShow, 0);
      if (next.getTime() < firstVisible.getTime()) {
        this._viewMonth = new Date(next.getFullYear(), next.getMonth(), 1);
      } else if (next.getTime() > lastVisible.getTime()) {
        this._viewMonth = kdrpAddMonths(new Date(next.getFullYear(), next.getMonth(), 1),
                                        -(this._monthsToShow - 1));
      }
      this._renderCalendar();
      var cell = this._popup.querySelector('[data-date="' + kdrpISO(next) + '"]');
      if (cell) { this._input.setAttribute('aria-activedescendant', cell.id); }
    }

    _onKeyDown(e) {
      if (!this._isEnabled || this._isReadOnly) { return; }
      var k = e.key;

      if (!this._isOpen) {
        if (k === 'ArrowDown' || k === 'Enter' || k === ' ' || k === 'Spacebar') {
          e.preventDefault();
          this._openCalendar();
        }
        return;
      }

      switch (k) {
        case 'ArrowLeft':  e.preventDefault(); this._moveFocus(-1); return;
        case 'ArrowRight': e.preventDefault(); this._moveFocus(1); return;
        case 'ArrowUp':    e.preventDefault(); this._moveFocus(-7); return;
        case 'ArrowDown':  e.preventDefault(); this._moveFocus(7); return;
        case 'PageUp':     e.preventDefault(); this._shiftMonths(-1); return;
        case 'PageDown':   e.preventDefault(); this._shiftMonths(1); return;
        case 'Home':
          e.preventDefault();
          this._moveFocus(-((this._focusDate.getDay() - this._firstDayOfWeek + 7) % 7));
          return;
        case 'End':
          e.preventDefault();
          this._moveFocus(6 - ((this._focusDate.getDay() - this._firstDayOfWeek + 7) % 7));
          return;
        case 'Enter':
        case ' ':
        case 'Spacebar':
          e.preventDefault();
          e.stopPropagation();          // must not submit the K2 form
          this._pickDate(this._focusDate);
          return;
        case 'Escape':
        case 'Esc':
          e.preventDefault();
          e.stopPropagation();
          this._closeCalendar();
          return;
        case 'Tab':
          this._closeCalendar();
          return;
        default:
          return;
      }
    }

    /* ---------------------------------------------------- custom properties */

    get Value() { return this._value; }
    set Value(v) {
      var next = (v == null) ? '' : String(v);
      if (next === this._value) { return; }
      if (next === '') { this._startDate = null; this._endDate = null; this._applyParsed(); return; }

      // Split on the configured separator, falling back to common ones.
      var parts = null;
      var sep = this._rangeSeparator;
      if (sep && next.indexOf(sep) > -1) {
        parts = next.split(sep);
      } else {
        var m = /^(.*?)\s*(?:-{1,2}|–|—|to|→)\s*(.*)$/i.exec(next);
        if (m && m[2]) { parts = [m[1], m[2]]; }
      }
      if (parts && parts.length >= 2) {
        this._startDate = kdrpParseFormatted(parts[0].trim(), this._dateFormat);
        this._endDate = kdrpParseFormatted(parts.slice(1).join(sep || '-').trim(), this._dateFormat);
      } else {
        this._startDate = kdrpParseFormatted(next.trim(), this._dateFormat);
        this._endDate = null;
      }
      this._normaliseOrder();
      this._applyParsed();
    }

    get StartDate() { return kdrpISO(this._startDate); }
    set StartDate(v) {
      var d = kdrpParse(v);
      if (kdrpSame(d, this._startDate) || (!d && !this._startDate)) { return; }
      this._startDate = d;
      this._normaliseOrder();
      this._applyParsed();
    }

    get EndDate() { return kdrpISO(this._endDate); }
    set EndDate(v) {
      var d = kdrpParse(v);
      if (kdrpSame(d, this._endDate) || (!d && !this._endDate)) { return; }
      this._endDate = d;
      this._normaliseOrder();
      this._applyParsed();
    }

    get TotalDays() { return this._totalDays; }
    set TotalDays(v) { /* read-back only */ }

    /** Swap if a rule set the dates the wrong way round. */
    _normaliseOrder() {
      if (this._startDate && this._endDate &&
          this._endDate.getTime() < this._startDate.getTime()) {
        var t = this._startDate; this._startDate = this._endDate; this._endDate = t;
      }
    }

    /** Shared tail for programmatic sets: refresh state without firing OnChanged. */
    _applyParsed() {
      this._pickPhase = (this._startDate && !this._endDate) ? 'end' : 'start';
      this._value = this._composeValue();
      this._totalDays = (this._startDate && this._endDate)
        ? String(kdrpSpan(this._startDate, this._endDate)) : '';
      if (this._hasRendered) {
        this._syncFieldText();
        this._updateClearButton();
        if (this._isOpen) { this._viewMonth = this._defaultViewMonth(); this._renderCalendar(); }
        kdrpRaise(this, 'Value', this._value);
        kdrpRaise(this, 'StartDate', kdrpISO(this._startDate));
        kdrpRaise(this, 'EndDate', kdrpISO(this._endDate));
        kdrpRaise(this, 'TotalDays', this._totalDays);
      }
    }

    get AllowPastDates() { return this._allowPastDates; }
    set AllowPastDates(v) {
      var n = kdrpBool(v);
      if (n === this._allowPastDates) { return; }
      this._allowPastDates = n;
      this._refreshIfOpen();
      kdrpRaise(this, 'AllowPastDates', n);
    }

    get AllowFutureDates() { return this._allowFutureDates; }
    set AllowFutureDates(v) {
      var n = kdrpBool(v);
      if (n === this._allowFutureDates) { return; }
      this._allowFutureDates = n;
      this._refreshIfOpen();
      kdrpRaise(this, 'AllowFutureDates', n);
    }

    get MinDate() { return kdrpISO(this._minDate); }
    set MinDate(v) {
      var d = kdrpParse(v);
      if (kdrpSame(d, this._minDate) || (!d && !this._minDate)) { return; }
      this._minDate = d;
      this._refreshIfOpen();
      kdrpRaise(this, 'MinDate', kdrpISO(d));
    }

    get MaxDate() { return kdrpISO(this._maxDate); }
    set MaxDate(v) {
      var d = kdrpParse(v);
      if (kdrpSame(d, this._maxDate) || (!d && !this._maxDate)) { return; }
      this._maxDate = d;
      this._refreshIfOpen();
      kdrpRaise(this, 'MaxDate', kdrpISO(d));
    }

    get DisableWeekends() { return this._disableWeekends; }
    set DisableWeekends(v) {
      var n = kdrpBool(v);
      if (n === this._disableWeekends) { return; }
      this._disableWeekends = n;
      this._refreshIfOpen();
      kdrpRaise(this, 'DisableWeekends', n);
    }

    get MinRangeDays() { return this._minRangeDays; }
    set MinRangeDays(v) {
      var n = kdrpInt(v, 1);
      if (n === this._minRangeDays) { return; }
      this._minRangeDays = n;
      this._refreshIfOpen();
      kdrpRaise(this, 'MinRangeDays', n);
    }

    get MaxRangeDays() { return this._maxRangeDays; }
    set MaxRangeDays(v) {
      var n = kdrpInt(v, 365);
      if (n === this._maxRangeDays) { return; }
      this._maxRangeDays = n;
      this._refreshIfOpen();
      kdrpRaise(this, 'MaxRangeDays', n);
    }

    get DateFormat() { return this._dateFormat; }
    set DateFormat(v) {
      var n = (v == null || v === '') ? 'dd/MM/yyyy' : String(v);
      if (n === this._dateFormat) { return; }
      this._dateFormat = n;
      this._value = this._composeValue();
      if (this._hasRendered) { this._syncFieldText(); }
      kdrpRaise(this, 'DateFormat', n);
    }

    get RangeSeparator() { return this._rangeSeparator; }
    set RangeSeparator(v) {
      var n = (v == null) ? '' : String(v);
      if (n === this._rangeSeparator) { return; }
      this._rangeSeparator = n;
      this._value = this._composeValue();
      if (this._hasRendered) { this._syncFieldText(); }
      kdrpRaise(this, 'RangeSeparator', n);
    }

    get MonthsToShow() { return this._monthsToShow; }
    set MonthsToShow(v) {
      var n = (String(v) === '1') ? 1 : 2;
      if (n === this._monthsToShow) { return; }
      this._monthsToShow = n;
      if (this._isOpen) {
        this._popup.classList.toggle('kdrp-popup--single', n === 1);
        this._renderCalendar();
        this._positionPopup();
      }
      kdrpRaise(this, 'MonthsToShow', n);
    }

    get FirstDayOfWeek() { return this._firstDayOfWeek; }
    set FirstDayOfWeek(v) {
      var n = parseInt(v, 10);
      if (isNaN(n) || n < 0 || n > 6) { n = 1; }
      if (n === this._firstDayOfWeek) { return; }
      this._firstDayOfWeek = n;
      this._refreshIfOpen();
      kdrpRaise(this, 'FirstDayOfWeek', n);
    }

    get Placeholder() { return this._placeholder; }
    set Placeholder(v) {
      var n = (v == null) ? '' : String(v);
      if (n === this._placeholder) { return; }
      this._placeholder = n;
      if (this._hasRendered) { this._input.placeholder = n; }
      kdrpRaise(this, 'Placeholder', n);
    }

    get ShowDayCount() { return this._showDayCount; }
    set ShowDayCount(v) {
      var n = kdrpBool(v);
      if (n === this._showDayCount) { return; }
      this._showDayCount = n;
      if (this._isOpen) { this._renderSummary(); }
      kdrpRaise(this, 'ShowDayCount', n);
    }

    get ShowClearButton() { return this._showClearButton; }
    set ShowClearButton(v) {
      var n = kdrpBool(v);
      if (n === this._showClearButton) { return; }
      this._showClearButton = n;
      this._updateClearButton();
      kdrpRaise(this, 'ShowClearButton', n);
    }

    _refreshIfOpen() { if (this._isOpen) { this._renderCalendar(); } }

    /* -------------------------------------------------- standard properties */

    get Width() { return this._width; }
    set Width(v) {
      if (String(v) === String(this._width)) { return; }
      this._width = v;
      if (this._hasRendered && this._root) {
        this._root.style.width = (v == null || v === '') ? ''
          : (isNaN(v) ? String(v) : v + 'px');
      }
      kdrpRaise(this, 'Width', v);
    }

    get Height() { return this._height; }
    set Height(v) {
      if (String(v) === String(this._height)) { return; }
      this._height = v;
      if (this._hasRendered && this._field) {
        this._field.style.height = (v == null || v === '') ? ''
          : (isNaN(v) ? String(v) : v + 'px');
      }
      kdrpRaise(this, 'Height', v);
    }

    get IsVisible() { return this._isVisible; }
    set IsVisible(v) {
      var n = kdrpBool(v);
      if (n === this._isVisible) { return; }
      this._isVisible = n;
      this.setAttribute('isvisible', n ? 'true' : 'false');
      this.style.display = n ? '' : 'none';
      if (!n) { this._closeCalendar(true); }
      kdrpRaise(this, 'IsVisible', n);
    }

    get IsEnabled() { return this._isEnabled; }
    set IsEnabled(v) {
      var n = kdrpBool(v);
      if (n === this._isEnabled) { return; }
      this._isEnabled = n;
      this.setAttribute('isenabled', n ? 'true' : 'false');
      this._updateInteractivity();
      kdrpRaise(this, 'IsEnabled', n);
    }

    get IsReadOnly() { return this._isReadOnly; }
    set IsReadOnly(v) {
      var n = kdrpBool(v);
      if (n === this._isReadOnly) { return; }
      this._isReadOnly = n;
      this.setAttribute('isreadonly', n ? 'true' : 'false');
      this._updateInteractivity();
      kdrpRaise(this, 'IsReadOnly', n);
    }

    get TabIndex() { return this._tabIndex; }
    set TabIndex(v) {
      var n = (v == null || v === '') ? '0' : String(v);
      if (n === this._tabIndex) { return; }
      this._tabIndex = n;
      if (this._hasRendered && this._input) { this._input.setAttribute('tabindex', n); }
      kdrpRaise(this, 'TabIndex', n);
    }

    _updateInteractivity() {
      if (!this._hasRendered) { return; }
      var interactive = this._isEnabled && !this._isReadOnly;
      this._input.disabled = !this._isEnabled;
      this._input.setAttribute('aria-disabled', interactive ? 'false' : 'true');
      this._root.classList.toggle('kdrp-root--disabled', !this._isEnabled);
      this._root.classList.toggle('kdrp-root--readonly', this._isReadOnly);
      if (!interactive) { this._closeCalendar(true); }
      this._updateClearButton();
    }

    _applyStandardProperties() {
      this.style.display = this._isVisible ? '' : 'none';
      if (this._width) {
        this._root.style.width = isNaN(this._width) ? String(this._width) : this._width + 'px';
      }
      if (this._height) {
        this._field.style.height = isNaN(this._height) ? String(this._height) : this._height + 'px';
      }
      this._input.placeholder = this._placeholder;
      this._input.setAttribute('tabindex', this._tabIndex);
      this._updateInteractivity();
    }

    onAttributeChanged(name, oldValue, newValue) {
      switch (name) {
        case 'value':            this.Value = newValue; break;
        case 'startdate':        this.StartDate = newValue; break;
        case 'enddate':          this.EndDate = newValue; break;
        case 'allowpastdates':   this.AllowPastDates = newValue; break;
        case 'allowfuturedates': this.AllowFutureDates = newValue; break;
        case 'mindate':          this.MinDate = newValue; break;
        case 'maxdate':          this.MaxDate = newValue; break;
        case 'disableweekends':  this.DisableWeekends = newValue; break;
        case 'minrangedays':     this.MinRangeDays = newValue; break;
        case 'maxrangedays':     this.MaxRangeDays = newValue; break;
        case 'dateformat':       this.DateFormat = newValue; break;
        case 'rangeseparator':   this.RangeSeparator = newValue; break;
        case 'monthstoshow':     this.MonthsToShow = newValue; break;
        case 'firstdayofweek':   this.FirstDayOfWeek = newValue; break;
        case 'placeholder':      this.Placeholder = newValue; break;
        case 'showdaycount':     this.ShowDayCount = newValue; break;
        case 'showclearbutton':  this.ShowClearButton = newValue; break;
        case 'width':            this.Width = newValue; break;
        case 'height':           this.Height = newValue; break;
        case 'isvisible':        this.IsVisible = newValue; break;
        case 'isenabled':        this.IsEnabled = newValue; break;
        case 'isreadonly':       this.IsReadOnly = newValue; break;
        case 'tabindex':         this.TabIndex = newValue; break;
        default:
          if (typeof super.onAttributeChanged === 'function') {
            super.onAttributeChanged(name, oldValue, newValue);
          }
      }
    }

    attributeChangedCallback(name, oldValue, newValue) {
      if (oldValue === newValue) { return; }
      if (KdrpBase !== HTMLElement && typeof super.attributeChangedCallback === 'function') {
        super.attributeChangedCallback(name, oldValue, newValue);
      } else {
        this.onAttributeChanged(name, oldValue, newValue);
      }
    }

    /* ------------------------------------------------------------ validation */

    getValue() { return this._value; }
    setValue(v) { this.Value = v; }

    Validate() {
      if (!this._isVisible || !this._isEnabled || this._isReadOnly) { return true; }
      if (!this._startDate || !this._endDate) { return false; }
      var span = kdrpSpan(this._startDate, this._endDate);
      if (span < this._minRangeDays) { return false; }
      if (this._maxRangeDays > 0 && span > this._maxRangeDays) { return false; }
      if (this._isBlocked(this._startDate) || this._isBlocked(this._endDate)) { return false; }
      return true;
    }

    /* ------------------------------------------------------- method dispatch */

    execute(objInfo) {
      objInfo = objInfo || {};
      var method = objInfo.methodName;

      function param(name) {
        var v = objInfo.methodParameters && objInfo.methodParameters[name];
        if (v == null) { v = objInfo.parameters && objInfo.parameters[name]; }
        if (v == null) { v = objInfo[name]; }
        if (v && typeof v === 'object' && !Array.isArray(v)) {
          v = (v[name] != null) ? v[name] : (v.value != null ? v.value : Object.values(v)[0]);
        }
        return v == null ? '' : String(v);
      }

      try {
        switch (method) {
          case 'Focus':
            if (this._input) { this._input.focus(); }
            break;
          case 'Clear':
            this._clearSelection(true);
            break;
          case 'OpenCalendar':
            this._openCalendar();
            break;
          case 'CloseCalendar':
            this._closeCalendar();
            break;
          case 'SetRange': {
            var s = kdrpParse(param('startDate'));
            var e2 = kdrpParse(param('endDate'));
            this._startDate = s;
            this._endDate = e2;
            this._normaliseOrder();
            this._applyParsed();
            break;
          }
          case 'SetStartDate':
            this.StartDate = param('date');
            break;
          case 'SetEndDate':
            this.EndDate = param('date');
            break;
          case 'GoToDate': {
            var g = kdrpParse(param('date'));
            if (g) {
              this._viewMonth = new Date(g.getFullYear(), g.getMonth(), 1);
              this._focusDate = g;
              if (this._isOpen) { this._renderCalendar(); }
            }
            break;
          }
          default:
            console.warn('[' + KDRP_TAG + '] unknown method:', method);
        }
      } catch (err) {
        console.error('[' + KDRP_TAG + '] execute error', method, err);
      }
      return '';
    }
  }

  window.customElements.define(KDRP_TAG, K2DateRangePicker);
})();
