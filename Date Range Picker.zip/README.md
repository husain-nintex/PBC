# Date Range Picker

A booking-style date range picker for Nintex K2 forms — the pattern used by flight and hotel
sites. The user clicks a start date, then an end date; the range highlights as they move the
pointer, and the calendar closes on the second click.

- **Tag:** `k2-date-range-picker`
- **Layout:** one or two month grids side by side
- **Output:** separate Start Date and End Date, plus a combined Value

## The three output properties

| Property | Format | Use it for |
|---|---|---|
| **Start Date (From)** | ISO `yyyy-MM-dd` | Binding to a K2 DateTime field |
| **End Date (To)** | ISO `yyyy-MM-dd` | Binding to a K2 DateTime field |
| **Full Date Range** (`Value`) | Formatted, e.g. `22/08/2026 - 27/08/2026` | The control's primary value — display, storage as text, or transferring the whole range in one rule |

`Total Days` is also exposed as a read-back property, giving the inclusive day count (22nd to
27th is 6 days).

Start Date and End Date always stay ISO regardless of `Date Format`, so the values you bind to
date fields are unambiguous. Only `Value` and the on-screen text follow the chosen format.

`Value` is two-way: set it from a rule as `"01/06/2026 - 09/06/2026"` and the control parses it
back into both dates. Setting Start Date and End Date individually works too, and a reversed pair
is swapped automatically.

## Restricting which dates can be picked

| Property | Default | Effect |
|---|---|---|
| **Allow Past Dates** | `true` | When false, every date before today is disabled. Today stays selectable. |
| **Allow Future Dates** | `true` | When false, every date after today is disabled. |
| **Earliest Selectable Date** | *(empty)* | Hard ISO floor, applied *on top of* Allow Past Dates — the later of the two wins. |
| **Latest Selectable Date** | *(empty)* | Hard ISO ceiling, applied on top of Allow Future Dates — the earlier of the two wins. |
| **Disable Weekends** | `false` | Blocks every Saturday and Sunday. |

## Restricting the length of the range

| Property | Default | Effect |
|---|---|---|
| **Minimum Range (days)** | `1` | Dates closer to the start than this are disabled while picking the end. `1` allows a single-day range. |
| **Maximum Range (days)** | `365` | Dates further from the start than this are disabled while picking the end. |

Both counts are **inclusive** — 22nd to 27th is 6 days, not 5.

The rules apply only while choosing the *end* date; the start date is unconstrained by them.
Clicking a date *before* the current start restarts the range from there, which is the standard
booking-site behaviour and never counts as an invalid attempt.

When a user clicks a date that breaks one of these rules, nothing is selected and
**Invalid Range Attempted** fires with `{ attemptedDays, minRangeDays, maxRangeDays, reason }`,
where `reason` is `below-minimum` or `above-maximum`. Use it to show a message on the form.

## Appearance

`Date Format` (five options), `Range Separator`, `Months Visible` (one or two), `Week Starts On`
(Sunday, Monday or Saturday), `Placeholder Text`, `Show Day Count`, `Show Clear Button`, `Height`.

## Events

`Changed`, `Start Date Selected`, `End Date Selected`, `Invalid Range Attempted`, `Cleared`,
`Calendar Opened`, `Calendar Closed`, `Focus`, `Blur`.

Ordering is specific-then-aggregate: picking an end date fires `End Date Selected` and then
`Changed`; clearing fires `Cleared` and then `Changed`. `Changed` fires only when the value
actually differs, and carries `{ value, startDate, endDate, totalDays, oldValue }`.

## Methods

`Focus`, `Clear`, `Open Calendar`, `Close Calendar`, `Set Range` (`startDate`, `endDate`),
`Set Start Date` (`date`), `Set End Date` (`date`) and `Go To Date` (`date`) — the last scrolls
the calendar to a given month without selecting anything. All date parameters take ISO
`yyyy-MM-dd`.

## Validation

`Validate` is declared in `supports` and implemented as `Validate()`. It returns `false` when
either date is missing, when the span breaks the minimum or maximum rule, or when either end
falls outside the allowed window. Hidden, disabled and read-only controls always pass.
`getValue()` / `setValue()` are implemented too, so K2's default validation still works.

## Keyboard

| Key | Behaviour |
|---|---|
| `↓` / `Enter` / `Space` | Open the calendar |
| `←` `→` | Move one day |
| `↑` `↓` | Move one week |
| `Page Up` / `Page Down` | Previous / next month |
| `Home` / `End` | First / last day of the current week |
| `Enter` / `Space` | Pick the focused day; does **not** submit the form |
| `Esc` | Close |
| `Tab` | Close, then move on |

Focus stays on the input throughout; the focused day is tracked with `aria-activedescendant`
against `role="gridcell"` elements, and a polite live region announces progress and day counts.

## Implementation notes

- **Runtime renders into the light DOM; design time uses Shadow DOM.** Manifest CSS is injected
  as document-level `<link>` elements, which do not cross a shadow boundary.
- **The calendar is portaled to `<body>` with `position: fixed` and no `z-index`.** K2 Designer
  overlays do not use z-index, so a positive value here would cover the rule designer. The popup
  re-reads `dir`, font and the K2 `--icon-*` variables from the host each time it opens, because a
  node in `<body>` inherits none of them, and it repositions on scroll and resize — closing if the
  field scrolls out of view.
- **All date maths is local-midnight based.** Bare `yyyy-MM-dd` strings are never handed to
  `Date.parse`, which treats them as UTC and shifts a day in negative offsets. Dates are built
  with `new Date(y, m, d)` and formatted by hand.
- **Hover repaints classes in place** rather than rebuilding the grid, so dragging across the
  calendar does not flicker.
- RTL is inherited from the form — the control never sets `direction` itself — and the layout uses
  logical CSS properties, so it mirrors without a second stylesheet. Note this follows the
  `k2-control-authoring` skill rather than `docs/Localization.md`, which recommends setting
  `direction` at the root; see that skill for why.
